import { SkillGroup } from './models';

export interface CapabilityStatement {
  statement: string;
}

export const CAPABILITY_STATEMENTS: CapabilityStatement[] = [
  {
    statement: 'Designing and maintaining REST APIs and backend services for emergency, disaster and smart-city applications.'
  },
  {
    statement: 'Implementing real-time communication and messaging workflows with WebSocket, MQTT and Firebase Cloud Messaging (FCM).'
  },
  {
    statement: 'Writing and optimizing Microsoft SQL Server queries, business logic validations and transactional stored procedures.'
  }
];

export const SKILLS_DATA: SkillGroup[] = [
  {
    label: 'Languages & Backend',
    items: ['Java', 'SQL', 'JavaScript', 'TypeScript', 'Spring Boot', 'Microservices', 'REST APIs']
  },
  {
    label: 'Frontend',
    items: ['Angular', 'HTML5', 'CSS']
  },
  {
    label: 'Data',
    items: ['Microsoft SQL Server', 'Stored Procedures', 'SQL Query Optimization', 'Redis']
  },
  {
    label: 'Real-time, IoT & Integration',
    items: [
      'MQTT',
      'WebSocket',
      'Firebase Cloud Messaging (FCM)',
      'Apache Kafka',
      'WhatsApp Business API',
      'Webhooks',
      'REST API Integration',
      'Apache NiFi'
    ]
  },
  {
    label: 'Cloud & Tooling',
    items: ['AWS', 'Git', 'GitHub', 'Maven', 'Docker (Basic)', 'Kubernetes (Basic)', 'Postman', 'JIRA', 'Eclipse', 'VS Code']
  }
];
