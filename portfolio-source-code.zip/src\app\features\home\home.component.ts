import { Component, ChangeDetectionStrategy, inject, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ContentService } from '../../data/content.service';
import { SeoService } from '../../core/seo.service';
import { MonoLabelComponent } from '../../shared/mono-label/mono-label.component';
import { CopyButtonComponent } from '../../shared/copy-button/copy-button.component';
import { ScrollRevealDirective } from '../../core/scroll-reveal.directive';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    RouterLink,
    MonoLabelComponent,
    CopyButtonComponent,
    ScrollRevealDirective
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HomeComponent implements OnInit {
  readonly content = inject(ContentService);
  private readonly seo = inject(SeoService);

  readonly profile = this.content.profile;
  readonly projects = this.content.orderedProjects;
  readonly skills = this.content.skills;
  readonly capabilities = this.content.capabilityStatements;

  readonly deployments = [
    'Namma112',
    'Maharashtra 112',
    'Kerala State Early Warning',
    'City Lighting Infrastructure'
  ];

  ngOnInit(): void {
    this.seo.updateTags({
      title: 'Vemala Srinivasulu — Full Stack Developer',
      description:
        'Personal portfolio of Vemala Srinivasulu, Full Stack Developer at Trinity Mobility, Bengaluru. Engineering backend systems behind emergency dispatch, disaster warning, and municipal infrastructure.',
      url: '/'
    });
  }

  getTechTriplet(stack: string[]): string {
    return stack.slice(0, 3).join(' · ');
  }
}
