import {
  Component,
  ChangeDetectionStrategy,
  inject,
  signal,
  computed,
  HostListener,
  ElementRef,
  viewChild
} from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { ThemeService } from '../../theme.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HeaderComponent {
  readonly themeService = inject(ThemeService);

  readonly isScrolled = signal(false);
  readonly isMobileMenuOpen = signal(false);
  readonly menuButtonRef = viewChild<ElementRef<HTMLButtonElement>>('menuButton');
  readonly firstMenuLinkRef = viewChild<ElementRef<HTMLAnchorElement>>('firstMenuLink');

  @HostListener('window:scroll', [])
  onWindowScroll(): void {
    if (typeof window !== 'undefined') {
      this.isScrolled.set(window.scrollY > 24);
    }
  }

  @HostListener('window:keydown', ['$event'])
  onKeyDown(event: KeyboardEvent): void {
    if (this.isMobileMenuOpen() && event.key === 'Escape') {
      this.closeMobileMenu();
    }
  }

  toggleMobileMenu(): void {
    const nextState = !this.isMobileMenuOpen();
    this.isMobileMenuOpen.set(nextState);
    this.updateBodyScrollLock(nextState);

    if (nextState) {
      setTimeout(() => {
        this.firstMenuLinkRef()?.nativeElement.focus();
      }, 50);
    } else {
      this.menuButtonRef()?.nativeElement.focus();
    }
  }

  closeMobileMenu(): void {
    if (this.isMobileMenuOpen()) {
      this.isMobileMenuOpen.set(false);
      this.updateBodyScrollLock(false);
      this.menuButtonRef()?.nativeElement.focus();
    }
  }

  private updateBodyScrollLock(lock: boolean): void {
    if (typeof document !== 'undefined') {
      if (lock) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = '';
      }
    }
  }
}
